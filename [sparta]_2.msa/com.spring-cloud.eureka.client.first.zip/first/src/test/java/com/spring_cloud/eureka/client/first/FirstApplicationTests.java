package com.spring_cloud.eureka.client.first;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
