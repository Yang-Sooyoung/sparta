package com.spring_cloud.eureka.client.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
